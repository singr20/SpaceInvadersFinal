public class gameChar {
    double x;
    double y;
    
    public gameChar(double x, double y){
        this.x = x;
        this.y = y;
    }
}
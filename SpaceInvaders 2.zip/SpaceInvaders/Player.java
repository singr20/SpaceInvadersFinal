public class Player extends gameChar{
    public Player(double x, double y){
        super(x,y);
    }
}